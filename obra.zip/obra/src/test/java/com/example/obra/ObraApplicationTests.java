package com.example.obra;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ObraApplicationTests {

	@Test
	void contextLoads() {
	}

}
